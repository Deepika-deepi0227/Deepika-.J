<?php require 'config/database.php'; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){ chk();
  $u=one(q('SELECT * FROM users WHERE email=?','s',trim($_POST['email']??'')));
  if($u && password_verify($_POST['password']??'',$u['password'])){
    session_regenerate_id(true); $_SESSION['uid']=$u['id']; $_SESSION['role']=$u['role']; $_SESSION['name']=$u['name'];
    header('Location: '.($u['role']==='company'?'company':'student').'/dashboard.php'); exit;
  } $err='Invalid email or password.'; }
$title='Login'; include 'includes/header.php'; ?>
<div class="card narrow"><h2>Login</h2><?php if(isset($_GET['ok'])):?><p class="ok">Registered! Please login.</p><?php endif; if($err):?><p class="alert"><?=e($err)?></p><?php endif;?>
<form method="post" data-validate><input type="hidden" name="t" value="<?=csrf()?>"><label>Email</label><input type="email" name="email" required><label>Password</label><input type="password" name="password" required><button class="btn">Login</button></form>
<p>New here? <a href="register.php">Register</a></p></div>
<?php include 'includes/footer.php'; ?>
