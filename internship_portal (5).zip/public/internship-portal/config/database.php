<?php
// Edit credentials / BASE if your setup differs (XAMPP defaults shown)
session_start();
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$db = new mysqli('db01.dbhost.dev', 'user_454v7gguf', 'p454v7gguf', 'db_454v7gguf');

$db->set_charset('utf8mb4');

define('BASE', '/internship-portal');
const STATUSES = ['Applied','Under Review','Shortlisted','Interview','Selected','Rejected'];
function e($s){return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');}
function q($sql, $t = '', ...$p){global $db; $s = $db->prepare($sql); if($t) $s->bind_param($t, ...$p); $s->execute(); return $s;}
function rows($s){return $s->get_result()->fetch_all(MYSQLI_ASSOC);}
function one($s){return $s->get_result()->fetch_assoc();}
function need($role){if(($_SESSION['role'] ?? '') !== $role){header('Location: '.BASE.'/login.php'); exit;}}
function csrf(){return $_SESSION['t'] ?? ($_SESSION['t'] = bin2hex(random_bytes(16)));}
function chk(){if(!hash_equals($_SESSION['t'] ?? '', $_POST['t'] ?? '')) die('Invalid request token.');}
function me(){return one(q('SELECT * FROM students WHERE user_id=?', 'i', $_SESSION['uid']));}
function cmp(){return one(q('SELECT * FROM companies WHERE user_id=?', 'i', $_SESSION['uid']));}
function badge($s){return '<span class="badge b-'.strtolower(str_replace(' ', '-', $s)).'">'.e($s).'</span>';}
// Validated upload: extension + real MIME + size (2MB). Returns stored filename or null.
function upload($f, $exts){
  if(!isset($f['tmp_name']) || $f['error'] !== 0 || $f['size'] > 2097152) return null;
  $x = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
  $mimes = ['pdf'=>['application/pdf'],'doc'=>['application/msword'],'docx'=>['application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/zip'],'jpg'=>['image/jpeg'],'jpeg'=>['image/jpeg'],'png'=>['image/png']];
  if(!in_array($x, $exts)) return null;
  $m = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
  if(!in_array($m, $mimes[$x])) return null;
  $n = bin2hex(random_bytes(12)).'.'.$x;
  return move_uploaded_file($f['tmp_name'], __DIR__.'/../uploads/'.$n) ? $n : null;
}
