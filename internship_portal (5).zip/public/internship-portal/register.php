<?php require 'config/database.php'; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){ chk();
  $n=trim($_POST['name']??''); $em=trim($_POST['email']??''); $pw=$_POST['password']??''; $role=($_POST['role']??'')==='company'?'company':'student'; $cn=trim($_POST['company_name']??'');
  if(!$n||!filter_var($em,FILTER_VALIDATE_EMAIL)||strlen($pw)<6||($role==='company'&&!$cn)) $err='Please fill all fields correctly (password min 6 characters).';
  elseif(one(q('SELECT id FROM users WHERE email=?','s',$em))) $err='Email already registered.';
  else{
    $db->begin_transaction();
    q('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)','ssss',$n,$em,password_hash($pw,PASSWORD_DEFAULT),$role); $id=$db->insert_id;
    if($role==='student') q('INSERT INTO students(user_id) VALUES(?)','i',$id); else q('INSERT INTO companies(user_id,company_name,company_email) VALUES(?,?,?)','iss',$id,$cn,$em);
    $db->commit(); header('Location: login.php?ok=1'); exit;
  } }
$title='Register'; include 'includes/header.php'; ?>
<div class="card narrow"><h2>Create account</h2><?php if($err):?><p class="alert"><?=e($err)?></p><?php endif;?>
<form method="post" data-validate><input type="hidden" name="t" value="<?=csrf()?>">
<label>I am a</label><select name="role" id="role"><option value="student">Student</option><option value="company">Company</option></select>
<label>Full name</label><input name="name" required value="<?=e($_POST['name']??'')?>">
<div id="cn" style="display:none"><label>Company name</label><input name="company_name"></div>
<label>Email</label><input type="email" name="email" required value="<?=e($_POST['email']??'')?>">
<label>Password</label><input type="password" name="password" minlength="6" required>
<button class="btn">Register</button></form><p>Have an account? <a href="login.php">Login</a></p></div>
<?php include 'includes/footer.php'; ?>
