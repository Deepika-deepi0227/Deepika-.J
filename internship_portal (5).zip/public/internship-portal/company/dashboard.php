<?php require '../config/database.php'; need('company'); $c=cmp(); $title='Dashboard';
$ni=one(q('SELECT COUNT(*) c FROM internships WHERE company_id=?','i',$c['id']))['c'];
$cnt=[]; foreach(rows(q('SELECT a.status,COUNT(*) c FROM applications a JOIN internships i ON i.id=a.internship_id WHERE i.company_id=? GROUP BY a.status','i',$c['id'])) as $r) $cnt[$r['status']]=$r['c'];
include '../includes/header.php'; ?>
<h2><?=e($c['company_name'])?> dashboard</h2>
<div class="grid"><div class="card stat"><b><?=$ni?></b>Internships posted</div><?php foreach(STATUSES as $st):?><div class="card stat"><b><?=$cnt[$st]??0?></b><?=badge($st)?></div><?php endforeach;?></div>
<p><a class="btn" href="add_internship.php">+ Add internship</a> <a class="btn ghost" href="applicants.php">View applicants</a></p>
<?php include '../includes/footer.php'; ?>
