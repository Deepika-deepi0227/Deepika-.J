<?php require '../config/database.php'; need('company'); $c=cmp(); $title='Applicants'; $iid=(int)($_GET['internship_id']??0);
if($_SERVER['REQUEST_METHOD']==='POST'){ chk(); $st=$_POST['status']??'';
  if(in_array($st,STATUSES)) q('UPDATE applications a JOIN internships i ON i.id=a.internship_id SET a.status=? WHERE a.id=? AND i.company_id=?','sii',$st,(int)$_POST['app_id'],$c['id']);
  header('Location: applicants.php'.($iid?"?internship_id=$iid":'')); exit; }
$sql='SELECT a.*,i.title,u.name,u.email,s.phone,s.college,s.course,s.year,s.skills FROM applications a JOIN internships i ON i.id=a.internship_id JOIN students s ON s.id=a.student_id JOIN users u ON u.id=s.user_id WHERE i.company_id=?';
$list=$iid?rows(q($sql.' AND i.id=? ORDER BY a.applied_date DESC','ii',$c['id'],$iid)):rows(q($sql.' ORDER BY a.applied_date DESC','i',$c['id']));
include '../includes/header.php'; ?>
<h2>Applicants</h2>
<?php if(!$list):?><p>No applicants yet.</p><?php endif; foreach($list as $a):?>
<div class="card"><div class="row"><h3><?=e($a['name'])?> <small class="muted">for <?=e($a['title'])?></small></h3><?=badge($a['status'])?></div>
<p>✉ <?=e($a['email'])?> · 📞 <?=e($a['phone'])?><br>🎓 <?=e($a['college'])?> — <?=e($a['course'])?> (<?=e($a['year'])?>)<br>🛠 <?=e($a['skills'])?><br>Applied <?=e(date('d M Y',strtotime($a['applied_date'])))?> · <a target="_blank" href="<?=BASE?>/uploads/<?=e($a['resume'])?>">📄 Resume</a></p>
<form method="post" class="inline"><input type="hidden" name="t" value="<?=csrf()?>"><input type="hidden" name="app_id" value="<?=$a['id']?>">
<select name="status"><?php foreach(STATUSES as $st):?><option <?=$a['status']===$st?'selected':''?>><?=$st?></option><?php endforeach;?></select>
<button class="btn sm">Update</button><button class="btn sm" name="status" value="Shortlisted">Shortlist</button><button class="btn sm danger" name="status" value="Rejected">Reject</button></form></div>
<?php endforeach; include '../includes/footer.php'; ?>
