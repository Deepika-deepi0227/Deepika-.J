<?php
session_start();

$page = $_GET['page'] ?? 'home';
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (isset($_POST['register'])) {
        $_SESSION['user'] = [
            'name' => $_POST['name'],
            'email' => $_POST['email'],
            'password' => $_POST['password'],
            'college' => $_POST['college'],
            'skills' => $_POST['skills'],
            'role' => $_POST['role']
        ];

        header("Location: ?page=login&registered=1");
        exit;
    }

    if (isset($_POST['login'])) {
        if (
            isset($_SESSION['user']) &&
            $_POST['email'] == $_SESSION['user']['email'] &&
            $_POST['password'] == $_SESSION['user']['password']
        ) {
            $_SESSION['loggedin'] = true;
            header("Location: ?page=dashboard");
            exit;
        } else {
            $message = "Please register first or check your details.";
        }
    }

    if (isset($_POST['logout'])) {
        session_destroy();
        header("Location: ?page=home");
        exit;
    }
}

if ($page == 'dashboard' && empty($_SESSION['loggedin'])) {
    header("Location: ?page=login");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>College Internship Portal</title>

<style>
*{box-sizing:border-box}
body{
    margin:0;
    font-family:Arial,sans-serif;
    background:#f4f7fb;
}
nav{
    background:#2563eb;
    padding:18px;
    color:white;
}
nav h2{display:inline;margin-right:25px}
nav a{
    color:white;
    text-decoration:none;
    margin:10px;
}
.container{
    width:85%;
    margin:35px auto;
}
.hero{
    text-align:center;
    padding:65px 15px;
}
.card,.box{
    background:white;
    padding:25px;
    margin:20px auto;
    border-radius:10px;
    box-shadow:0 3px 10px #ccc;
}
.box{max-width:450px;margin:45px auto}
input,select{
    width:100%;
    padding:12px;
    margin:8px 0;
}
button{
    background:#2563eb;
    color:white;
    border:0;
    padding:12px 22px;
    border-radius:5px;
    cursor:pointer;
}
table{
    width:100%;
    border-collapse:collapse;
}
th,td{
    padding:12px;
    border:1px solid #ddd;
    text-align:left;
}
th{background:#2563eb;color:white}
.message{color:green}
.error{color:red}
</style>
</head>

<body>

<nav>
<h2>Internship Portal</h2>
<a href="?page=home">Home</a>
<a href="?page=register">Register</a>
<a href="?page=login">Login</a>
<a href="?page=internships">Internships</a>
<a href="?page=dashboard">Dashboard</a>
</nav>

<?php if($page == 'home'){ ?>

<div class="hero">
<h1>College Internship Application Portal</h1>
<p>Connect Students with Companies and Find the Right Internship.</p>
<a href="?page=register"><button>Get Started</button></a>
</div>

<div class="container">
<div class="card">
<h2>For Students</h2>
<p>Register, create your profile and apply for internships.</p>
</div>
<div class="card">
<h2>For Companies</h2>
<p>Post internship opportunities and manage applicants.</p>
</div>
<div class="card">
<h2>For Admin</h2>
<p>Manage students, companies and internships.</p>
</div>
</div>

<?php } elseif($page == 'register'){ ?>

<div class="box">
<h2>Student Registration</h2>

<form method="POST" action="?page=register">
<input type="text" name="name" placeholder="Full Name" required>
<input type="email" name="email" placeholder="Email" required>
<input type="password" name="password" placeholder="Password" required>
<input type="text" name="college" placeholder="College Name" required>
<input type="text" name="skills" placeholder="Skills" required>

<select name="role" required>
<option value="Student">Student</option>
<option value="Company">Company</option>
<option value="Admin">Admin</option>
</select>

<button type="submit" name="register">Register</button>
</form>

<p>Already registered? <a href="?page=login">Login</a></p>
</div>

<?php } elseif($page == 'login'){ ?>

<div class="box">
<h2>Login</h2>

<?php
if(isset($_GET['registered'])){
    echo '<p class="message">Registration successful! Please login.</p>';
}
if($message != ''){
    echo '<p class="error">'.$message.'</p>';
}
?>

<form method="POST" action="?page=login">
<input type="email" name="email" placeholder="Email" required>
<input type="password" name="password" placeholder="Password" required>
<button type="submit" name="login">Login</button>
</form>

<p>New user? <a href="?page=register">Register here</a></p>
</div>

<?php } elseif($page == 'internships'){ ?>

<div class="container">
<h1>Available Internships</h1>

<div class="card">
<h2>Web Development Intern</h2>
<p>Company: ABC Technologies</p>
<p>Skills: HTML, CSS, PHP</p>
<p>Duration: 3 Months</p>
<p>Location: Chennai</p>
</div>

<div class="card">
<h2>Python Developer Intern</h2>
<p>Company: Tech Solutions</p>
<p>Skills: Python, SQL</p>
<p>Duration: 6 Months</p>
<p>Location: Bangalore</p>
</div>

<div class="card">
<h2>Data Science Intern</h2>
<p>Company: Data Corp</p>
<p>Skills: Python, Data Science</p>
<p>Duration: 6 Months</p>
<p>Location: Remote</p>
</div>
</div>

<?php } elseif($page == 'dashboard'){ ?>

<div class="container">
<h1>Student Dashboard</h1>

<div class="card">
<h2>My Profile</h2>

<p><b>Name:</b>
<?= htmlspecialchars($_SESSION['user']['name']) ?></p>

<p><b>Email:</b>
<?= htmlspecialchars($_SESSION['user']['email']) ?></p>

<p><b>College:</b>
<?= htmlspecialchars($_SESSION['user']['college']) ?></p>

<p><b>Skills:</b>
<?= htmlspecialchars($_SESSION['user']['skills']) ?></p>

<p><b>Role:</b>
<?= htmlspecialchars($_SESSION['user']['role']) ?></p>
</div>

<div class="card">
<h2>My Applications</h2>
<p>You can explore internships from the Internships page.</p>
</div>

<form method="POST">
<button type="submit" name="logout">Logout</button>
</form>

</div>

<?php } ?>

</body>
</html>
