document.querySelectorAll('form[data-validate]').forEach(f=>f.addEventListener('submit',e=>{
  let ok=true;f.querySelectorAll('[required]').forEach(i=>{const bad=!i.value.trim();i.classList.toggle('bad',bad);if(bad)ok=false;});
  const p=f.querySelector('input[name=password][minlength]');if(p&&p.value.length<6){p.classList.add('bad');ok=false;}
  if(!ok){e.preventDefault();alert('Please fill in all required fields correctly.');}}));
const role=document.getElementById('role');
if(role){const t=()=>{const c=document.getElementById('cn'),co=role.value==='company';c.style.display=co?'block':'none';c.querySelector('input').required=co;};role.addEventListener('change',t);t();}
