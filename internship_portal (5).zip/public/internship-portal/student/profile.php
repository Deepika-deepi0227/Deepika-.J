<?php require '../config/database.php'; need('student'); $s=me(); $title='Profile'; $msg=$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){ chk();
  $name=trim($_POST['name']??''); $ph=trim($_POST['phone']??''); $col=trim($_POST['college']??''); $cr=trim($_POST['course']??''); $yr=trim($_POST['year']??''); $sk=trim($_POST['skills']??'');
  if(!$name) $err='Name is required.'; elseif($ph!==''&&!preg_match('/^[0-9+\-\s]{7,15}$/',$ph)) $err='Invalid phone number.';
  else{
    $res=$s['resume']; $ph_=$s['profile_photo'];
    if(!empty($_FILES['resume']['name'])){ $f=upload($_FILES['resume'],['pdf','doc','docx']); if($f)$res=$f; else $err='Resume must be PDF/DOC/DOCX up to 2MB.'; }
    if(!empty($_FILES['photo']['name'])){ $f=upload($_FILES['photo'],['jpg','jpeg','png']); if($f)$ph_=$f; else $err='Photo must be JPG/PNG up to 2MB.'; }
    if(!$err){
      q('UPDATE users SET name=? WHERE id=?','si',$name,$_SESSION['uid']); $_SESSION['name']=$name;
      q('UPDATE students SET phone=?,college=?,course=?,year=?,skills=?,resume=?,profile_photo=? WHERE id=?','sssssssi',$ph,$col,$cr,$yr,$sk,$res,$ph_,$s['id']);
      $msg='Profile saved.'; $s=me();
    } } }
$u=one(q('SELECT name,email FROM users WHERE id=?','i',$_SESSION['uid']));
include '../includes/header.php'; ?>
<div class="card narrow wide"><h2>My Profile</h2><?php if($msg):?><p class="ok"><?=e($msg)?></p><?php endif; if($err):?><p class="alert"><?=e($err)?></p><?php endif;?>
<?php if($s['profile_photo']):?><img class="avatar" src="<?=BASE?>/uploads/<?=e($s['profile_photo'])?>" alt="photo"><?php endif;?>
<form method="post" enctype="multipart/form-data" data-validate><input type="hidden" name="t" value="<?=csrf()?>">
<label>Name</label><input name="name" required value="<?=e($u['name'])?>"><label>Email</label><input value="<?=e($u['email'])?>" disabled>
<label>Phone</label><input name="phone" value="<?=e($s['phone'])?>"><label>College</label><input name="college" value="<?=e($s['college'])?>">
<label>Course</label><input name="course" value="<?=e($s['course'])?>"><label>Year</label><select name="year"><?php foreach(['','1st','2nd','3rd','4th','Graduate'] as $y):?><option <?=$s['year']===$y?'selected':''?>><?=$y?></option><?php endforeach;?></select>
<label>Skills (comma separated)</label><input name="skills" placeholder="PHP, MySQL, Python" value="<?=e($s['skills'])?>">
<label>Resume (PDF/DOC/DOCX, max 2MB)</label><input type="file" name="resume" accept=".pdf,.doc,.docx"><?php if($s['resume']):?><small><a target="_blank" href="<?=BASE?>/uploads/<?=e($s['resume'])?>">Current resume</a></small><?php endif;?>
<label>Profile photo (JPG/PNG)</label><input type="file" name="photo" accept=".jpg,.jpeg,.png"><button class="btn">Save profile</button></form></div>
<?php include '../includes/footer.php'; ?>
