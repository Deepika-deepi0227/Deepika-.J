<?php require '../config/database.php'; need('student'); $s=me(); $title='Dashboard';
$cnt=[]; foreach(rows(q('SELECT status,COUNT(*) c FROM applications WHERE student_id=? GROUP BY status','i',$s['id'])) as $r) $cnt[$r['status']]=$r['c'];
$recent=rows(q('SELECT a.status,a.applied_date,i.title,c.company_name FROM applications a JOIN internships i ON i.id=a.internship_id JOIN companies c ON c.id=i.company_id WHERE a.student_id=? ORDER BY a.applied_date DESC LIMIT 5','i',$s['id']));
include '../includes/header.php'; ?>
<h2>Welcome, <?=e($_SESSION['name'])?> 👋</h2>
<?php if(!$s['college']||!$s['skills']):?><p class="alert">Complete your <a href="profile.php">profile</a> to stand out.</p><?php endif;?>
<div class="grid"><?php foreach(STATUSES as $st):?><div class="card stat"><b><?=$cnt[$st]??0?></b><?=badge($st)?></div><?php endforeach;?></div>
<h3>Recent applications</h3><div class="card"><?php if(!$recent):?>No applications yet. <a href="internships.php">Browse internships</a><?php endif; foreach($recent as $r):?>
<div class="row"><span><b><?=e($r['title'])?></b> · <?=e($r['company_name'])?></span><?=badge($r['status'])?></div><?php endforeach;?></div>
<?php include '../includes/footer.php'; ?>
