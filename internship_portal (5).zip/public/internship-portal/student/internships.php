<?php 
require '../config/database.php'; 
need('student'); 
$title='Internships';
$k='%'.trim($_GET['k']??'').'%';
 $l='%'.trim($_GET['loc']??'').'%'; $d='%'.trim($_GET['dur']??'').'%';
$list=rows(q("SELECT i.*,c.company_name,(SELECT COUNT(*) FROM applications a JOIN students s ON s.id=a.student_id WHERE a.internship_id=i.id AND s.user_id=?) applied FROM internships i JOIN companies c ON c.id=i.company_id WHERE i.deadline>=CURDATE() AND (i.title LIKE ? OR i.required_skills LIKE ? OR c.company_name LIKE ?) AND i.location LIKE ? AND i.duration LIKE ? ORDER BY i.created_at DESC",'isssss',$_SESSION['uid'],$k,$k,$k,$l,$d));
include '../includes/header.php'; ?>
<h2>Find internships</h2>
<form class="filters" method="get"><input name="k" placeholder="Title, skill or company" value="<?=e($_GET['k']??'')?>"><input name="loc" placeholder="Location" value="<?=e($_GET['loc']??'')?>"><input name="dur" placeholder="Duration (e.g. 3 months)" value="<?=e($_GET['dur']??'')?>"><button class="btn">Search</button></form>
<div class="grid"><?php if(!$list):?><p>No internships match your search.</p><?php endif; foreach($list as $i):?>
<div class="card"><h3><?=e($i['title'])?></h3><p class="muted"><?=e($i['company_name'])?> · 📍 <?=e($i['location']?:'Remote')?></p>
<p><?=e(mb_strimwidth($i['description'],0,110,'…'))?></p><p>🛠 <?=e($i['required_skills'])?></p><p>⏱ <?=e($i['duration'])?> · 💰 <?=e($i['stipend']?:'Unpaid')?> · Apply by <?=e($i['deadline'])?></p>
<a class="btn sm" href="apply.php?id=<?=$i['id']?>"><?=$i['applied']?'View (Applied)':'View & Apply'?></a></div><?php endforeach;?></div>
<?php include '../includes/footer.php'; ?>
