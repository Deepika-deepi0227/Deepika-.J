<?php require '../config/database.php'; need('student'); $s=me(); $title='Apply'; $id=(int)($_GET['id']??$_POST['id']??0);
$i=one(q('SELECT i.*,c.company_name,c.company_description FROM internships i JOIN companies c ON c.id=i.company_id WHERE i.id=?','i',$id));
if(!$i){header('Location: internships.php'); exit;}
$done=one(q('SELECT status FROM applications WHERE internship_id=? AND student_id=?','ii',$id,$s['id'])); $err='';
if($_SERVER['REQUEST_METHOD']==='POST' && !$done){ chk();
  if($i['deadline']<date('Y-m-d')) $err='The deadline has passed.';
  else{ $r=$s['resume'];
    if(!empty($_FILES['resume']['name'])){ $r=upload($_FILES['resume'],['pdf','doc','docx']); if(!$r) $err='Resume must be PDF/DOC/DOCX up to 2MB.'; }
    if(!$err&&!$r) $err='Please upload a resume.';
    if(!$err){ q('INSERT INTO applications(internship_id,student_id,resume) VALUES(?,?,?)','iis',$id,$s['id'],$r); header('Location: applications.php?ok=1'); exit; } } }
include '../includes/header.php'; ?>
<div class="card narrow wide"><h2><?=e($i['title'])?></h2><p class="muted"><?=e($i['company_name'])?> · 📍 <?=e($i['location'])?></p>
<p><?=nl2br(e($i['description']))?></p><p><b>Skills:</b> <?=e($i['required_skills'])?></p><p><b>Duration:</b> <?=e($i['duration'])?> · <b>Stipend:</b> <?=e($i['stipend']?:'Unpaid')?> · <b>Deadline:</b> <?=e($i['deadline'])?></p><hr>
<?php if($done):?><p class="ok">You already applied. Status: <?=badge($done['status'])?></p>
<?php else: if($err):?><p class="alert"><?=e($err)?></p><?php endif;?>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="t" value="<?=csrf()?>"><input type="hidden" name="id" value="<?=$id?>">
<label>Resume <?=$s['resume']?'(optional – your profile resume will be used)':'(required)'?></label><input type="file" name="resume" accept=".pdf,.doc,.docx"><button class="btn">Submit application</button></form><?php endif;?></div>
<?php include '../includes/footer.php'; ?>
