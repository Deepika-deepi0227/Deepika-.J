<?php require '../config/database.php'; need('student'); $s=me(); $title='My Applications';
$list=rows(q('SELECT a.*,i.title,i.location,c.company_name FROM applications a JOIN internships i ON i.id=a.internship_id JOIN companies c ON c.id=i.company_id WHERE a.student_id=? ORDER BY a.applied_date DESC','i',$s['id']));
include '../includes/header.php'; ?>
<h2>My Applications</h2><?php if(isset($_GET['ok'])):?><p class="ok">Application submitted!</p><?php endif;?>
<div class="card"><?php if(!$list):?>Nothing yet. <a href="internships.php">Find internships</a><?php endif; foreach($list as $a):?>
<div class="row"><span><b><?=e($a['title'])?></b> · <?=e($a['company_name'])?><br><small class="muted">Applied <?=e(date('d M Y',strtotime($a['applied_date'])))?></small></span><?=badge($a['status'])?></div><?php endforeach;?></div>
<?php include '../includes/footer.php'; ?>
