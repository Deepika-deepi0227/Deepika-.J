<?php
session_start();

if (!isset($_SESSION['users'])) $_SESSION['users'] = [];

$page = $_GET['page'] ?? 'home';
$error = '';

if (isset($_GET['logout'])) {
    unset($_SESSION['user']);
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['register'])) {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $pass = $_POST['password'];

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 4) {
            $error = "Enter a valid email and password (at least 4 characters).";
            $page = 'register';
        } elseif (isset($_SESSION['users'][$email])) {
            $error = "Email already registered. Please login.";
            $page = 'login';
        } else {
            $_SESSION['users'][$email] = [
                'name' => $name,
                'password' => password_hash($pass, PASSWORD_DEFAULT)
            ];
            header("Location: index.php?page=login&registered=1");
            exit;
        }
    }

    if (isset($_POST['login'])) {
        $email = trim($_POST['email']);
        $pass = $_POST['password'];

        if (isset($_SESSION['users'][$email]) &&
            password_verify($pass, $_SESSION['users'][$email]['password'])) {
            session_regenerate_id(true);
            $_SESSION['user'] = $email;
            header("Location: index.php?page=dashboard");
            exit;
        } else {
            $error = "Incorrect email or password.";
            $page = 'login';
        }
    }
}

$logged = isset($_SESSION['user'], $_SESSION['users'][$_SESSION['user']]);

if (in_array($page, ['dashboard','internships']) && !$logged) {
    header("Location: index.php?page=login");
    exit;
}

$pics = [
    'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600',
    'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600',
    'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=600',
    'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=600'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>College Internship Portal</title>
<style>
*{box-sizing:border-box}
body{margin:0;font-family:Arial,sans-serif;background:#fff0f6;color:#252044}
nav{background:#30152f;color:white;padding:18px 5%;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px}
.logo{font-weight:bold;font-size:20px;color:#ffc1df}
nav a{color:white;text-decoration:none;margin:7px;font-size:14px}
nav a:hover{color:#ff8fc7}
.hero{padding:55px 7%;display:flex;align-items:center;justify-content:space-between;gap:30px;flex-wrap:wrap;background:linear-gradient(120deg,#ffd5e8,#fff0f6)}
.hero .text{flex:1;min-width:250px}
h1{font-size:42px;color:#381831;margin:10px 0}
h1 span{color:#df3889}
.hero img{width:42%;min-width:250px;max-width:470px;height:260px;object-fit:cover;border-radius:25px}
p{line-height:1.7}
.btn,button{display:inline-block;background:#d93687;color:white;border:0;border-radius:9px;padding:12px 20px;text-decoration:none;cursor:pointer;font-size:15px}
.btn:hover,button:hover{background:#35152f}
.section{padding:30px 5%;text-align:center}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:20px;margin-top:25px}
.card{background:white;border-radius:15px;overflow:hidden;box-shadow:0 5px 20px #5b244015;text-align:left}
.card img{width:100%;height:145px;object-fit:cover}
.card .inside{padding:16px}
.card h3{color:#a92a68}
.tag{display:inline-block;background:#ffe0ef;padding:6px 9px;border-radius:12px;margin:3px;font-size:12px}
.formbox{background:white;width:92%;max-width:430px;margin:45px auto;padding:30px;border-radius:18px;box-shadow:0 8px 30px #4b18351c}
.formbox h2{text-align:center;color:#a92a68}
input{width:100%;padding:13px;margin:9px 0;border:1px solid #e4c8d7;border-radius:8px;font-size:15px}
.formbox button{width:100%;margin-top:12px}
.error{background:#ffe0e8;color:#a00040;padding:10px;border-radius:8px}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:15px;margin:20px 0}
.stat{background:#ffe0ef;padding:22px;border-radius:12px;text-align:center}
.stat b{display:block;font-size:28px;color:#d93687}
footer{text-align:center;padding:25px;background:#30152f;color:#ffe1f0;margin-top:30px}
@media(max-width:600px){h1{font-size:32px}.hero img{width:100%}nav{justify-content:center}}
</style>
</head>
<body>
<nav>
<div class="logo">🎓 College Internship Portal</div>
<div>
<a href="index.php">Home</a>
<a href="index.php?page=internships">Internships</a>
<a href="index.php?page=login">Login</a>
<a href="index.php?page=register">Register</a>
<?php if($logged): ?><a href="index.php?page=dashboard">Dashboard</a><a href="index.php?logout=1">Logout</a><?php endif; ?>
</div>
</nav>

<?php if($page==='home'): ?>
<section class="hero">
<div class="text">
<p>🎓 YOUR CAREER STARTS HERE</p>
<h1>Build Your Skills.<br><span>Shape Your Future.</span></h1>
<p>Explore internships, gain real-world experience and take the next step in your career.</p>
<a class="btn" href="index.php?page=register">Get Started →</a>
<a class="btn" style="background:#35152f" href="index.php?page=internships">Explore Internships</a>
</div>
<img src="<?= $pics[2] ?>" alt="Students working together">
</section>
<section class="section">
<h2>Why Choose Our Portal?</h2>
<div class="cards">
<div class="card"><img src="<?= $pics[0] ?>" alt="Web development"><div class="inside"><h3>💻 Build Skills</h3><p>Learn practical technical skills.</p></div></div>
<div class="card"><img src="<?= $pics[1] ?>" alt="Online learning"><div class="inside"><h3>🚀 Real Experience</h3><p>Discover opportunities and apply.</p></div></div>
<div class="card"><img src="<?= $pics[3] ?>" alt="Teamwork"><div class="inside"><h3>🌟 Grow Your Career</h3><p>Start building your professional future.</p></div></div>
</div>
</section>

<?php elseif($page==='register'): ?>
<div class="formbox">
<h2>📝 Create Your Account</h2>
<p>Join us and start your internship journey!</p>
<?php if($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
<form method="post" action="index.php?page=register">
<input name="name" placeholder="Full Name" required>
<input name="email" type="email" placeholder="Email Address" required>
<input name="password" type="password" placeholder="Create Password (minimum 4 characters)" required minlength="4">
<button name="register">Register Now</button>
</form>
<p>Already have an account? <a href="index.php?page=login">Login</a></p>
<img src="<?= $pics[2] ?>" alt="Students learning" style="width:100%;height:130px;object-fit:cover;border-radius:10px">
</div>

<?php elseif($page==='login'): ?>
<div class="formbox">
<h2>💗 Welcome Back!</h2>
<p>Login to access your dashboard.</p>
<?php if($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
<?php if(isset($_GET['registered'])): ?><p style="color:green">Registration successful! Please login.</p><?php endif; ?>
<form method="post" action="index.php?page=login">
<input name="email" type="email" placeholder="Email Address" required>
<input name="password" type="password" placeholder="Password" required>
<button name="login">Login</button>
</form>
<p>New student? <a href="index.php?page=register">Register here</a></p>
<img src="<?= $pics[0] ?>" alt="Laptop and coding" style="width:100%;height:130px;object-fit:cover;border-radius:10px">
</div>

<?php elseif($page==='dashboard' && $logged): ?>
<section class="section">
<h1>🎉 Dashboard Successful!</h1>

<h2>Welcome, 
<span><?= htmlspecialchars($_SESSION['users'][$_SESSION['user']]['name']) ?>!</span>
</h2>

<p>Your login was successful. Welcome to your Student Dashboard!</p>
<p>Your student dashboard is ready. Keep learning and growing!</p>
<div class="stats">
<div class="stat">💼<b>4</b>Internships</div>
<div class="stat">📨<b>0</b>Applications</div>
<div class="stat">⭐<b>0</b>Shortlisted</div>
</div>
<div class="cards">
<div class="card"><img src="<?= $pics[2] ?>" alt="Student profile"><div class="inside"><h3>👤 My Profile</h3><p>Name: <?= htmlspecialchars($_SESSION['users'][$_SESSION['user']]['name']) ?></p><p>Email: <?= htmlspecialchars($_SESSION['user']) ?></p></div></div>
<div class="card"><img src="<?= $pics[0] ?>" alt="Internship skills"><div class="inside"><h3>💻 Explore Opportunities</h3><p>Discover internships matching your interests.</p><a class="btn" href="index.php?page=internships">View Internships</a></div></div>
<div class="card"><img src="<?= $pics[3] ?>" alt="Career growth"><div class="inside"><h3>🌸 Keep Growing!</h3><p>Every small step brings you closer to your dream career.</p></div></div>
</div>
</section>

<?php elseif($page==='internships' && $logged): ?>
<section class="section">
<h1>Available <span>Internships</span></h1>
<p>Discover opportunities and kickstart your career!</p>
<div class="cards">
<?php
$jobs=[
['Web Development Intern','Tech Solutions Pvt Ltd','HTML, CSS, PHP'],
['Data Analyst Intern','DataVista Analytics','Python, SQL'],
['UI/UX Design Intern','Creative Minds','Figma, Design'],
['Python Developer Intern','NextGen Technologies','Python, Django'],
['Digital Marketing Intern','GrowthHub','SEO, Marketing'],
['Content Writer Intern','Bright Media','Writing, Research']
];
foreach($jobs as $i=>$job): ?>
<div class="card"><img src="<?= $pics[$i%4] ?>" alt="Internship opportunity"><div class="inside">
<h3><?= htmlspecialchars($job[0]) ?></h3>
<p>🏢 <?= htmlspecialchars($job[1]) ?></p>
<p>Skills: <?= htmlspecialchars($job[2]) ?></p>
<span class="tag">Internship</span><span class="tag">Career Growth</span>
<button onclick="alert('Application submitted successfully!')">Apply Now →</button>
</div></div>
<?php endforeach; ?>
</div>
</section>

<?php else: ?>
<div class="formbox"><h2>Page not found</h2><a class="btn" href="index.php">Go Home</a></div>
<?php endif; ?>

<footer>🎓 College Internship Portal | Learn • Grow • Succeed © 2026</footer>
</body>
</html>